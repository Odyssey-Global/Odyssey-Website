<!DOCTYPE html>
<html lang="en">

<body>
    <div class="cx-style"
        style="background-color: #1A5AA5; text-align: center; height: 390px; display: flex; align-items: center; justify-content: center;">
        <div>
            <h1 style="color: white;">Ready to deliver personal </br>
                CX at scale?</h1>
            <p style="color: white;">We are not just a staffing company; we are </br> dedicated to empowering
                individuals</p>
            <div class="d-flex justify-content-center gap-3">
                <a class="btn btn-ghost-dark btn-pointer Orange-btn" href="#">Connect with us</a>
            </div>
        </div>
    </div>
</body>

</html>